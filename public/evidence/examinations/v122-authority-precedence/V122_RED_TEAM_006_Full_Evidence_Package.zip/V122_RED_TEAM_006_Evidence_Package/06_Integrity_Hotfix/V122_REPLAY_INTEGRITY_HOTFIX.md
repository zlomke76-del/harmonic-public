# V122 Exact-Replay Integrity Hotfix

Version: 0.2.10

## Problem
The V122 UI loaded the downstream Pack-to-Harmonic packet with the generic V113 `enforceNoConstitutionalAnswerPreload` scanner enabled. That scanner intentionally rejects execution-disposition terms such as `PERMIT`, `REFUSE`, `ALLOW`, and `BLOCK` anywhere in the packet.

V122 necessarily carries `PERMIT` and `REFUSE` as the two conflicting authority-source dispositions under examination, plus the Pack-derived constitution result. Those values are downstream Pack output, not precomputed answers supplied to the Pack input. The generic scanner therefore produced a false-positive integrity failure before the packet could be replayed.

## Correction
For V122 only, the UI no longer applies the generic V113 downstream packet scanner. The prospective no-answer-smuggling property remains enforced by `npm run test:v122-authority-precedence` against `case-a-specialty-input.json` and `case-b-specialty-input.json`, including rejection of winner, priority, override, selected-authority, governing-authority, governing-path, and constitution-status fields. Candidate-order reversal remains a required invariant.

## Evidence boundary
No V122 frozen proposition, Pack input, Pack output, Harmonic packet, precedence relation, or expected result was modified. This correction changes only the harness admission check used before exact packet transport.
