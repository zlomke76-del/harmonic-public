# Apply V122 exact-replay integrity hotfix

Replace the included files at their repository-relative paths.

This hotfix corrects only the harness-side replay admission check for V122. It does not alter the frozen V122 proposition, Specialty Pack inputs/outputs, exact Harmonic packets, or expected results.

After applying, run:

```bash
npm run test:v122-authority-precedence
npm run test:v121-authority-scope-sufficiency
npm run test:v120-authority-chain-continuity
```
