# V122 Test Artifacts

These files preserve the exact RED TEAM 006 Specialty Pack examination artifacts included in the final harness.

Primary PASS / FAIL belongs to the Specialty Pack precedence/conflict-admission boundary. The Harmonic packets are downstream exact-replay inputs and Harmonic output is secondary witness evidence only.

Run the executable fixture test with:

```bash
npm run test:v122-authority-precedence
```
