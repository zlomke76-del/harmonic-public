# RED TEAM 004 / V120 — Evidence Submission

Wojciech — the frozen RED TEAM 004 pair has now been executed.

I am submitting the complete package for your independent adjudication against the proposition we froze prospectively:

> **Valid authority artifact ≠ currently intact authority chain.**

The submitted disposition is **PASS — BOUNDED**.

In Case A, the independently represented R₀→B empowerment path remains governing. The Pack returns `CONSTITUTED`, retains Source A as governing, and the downstream Harmonic replay returns `PERMITTED`.

In Case B, the B→C delegation and C authority instrument remain unchanged, current, signed, attributable and internally valid, but independent root evidence reports that R₀ no longer empowers B for the proposition and competence has moved to B₂. No B₂→C delegation is supplied. The Pack returns `UNRESOLVED_AUTHORITY_CHAIN`, with no proposition value and no governing source. Harmonic subsequently returns `REFUSED`.

One detail is intentionally preserved rather than smoothed over: Harmonic's `authority_continuity` primitive still reports `AUTHORITY_CONTINUOUS` in Case B. The refusal is driven by the invalidating constituted-state transition carried through `understanding_continuity` / runtime admissibility. Accordingly, I am **not** claiming that Harmonic independently reconstructs the R₀→B→C break. The bounded evidence is:

**Pack detects broken empowerment path → constituted state becomes UNRESOLVED → Harmonic refuses that constituted state.**

The package includes the frozen protocol, responsibility map, exact A/B Pack inputs and outputs, exact Harmonic packets, executable reference Pack, fixture test, full current-production replay records, complete V120 harness package, full-files delta, and SHA-256 manifest.

Please adjudicate only the frozen proposition under the prospective PASS / FAIL / UNRESOLVED rules. If you find a break, preserve the break. No broader claim is requested.

— Tim
